# MINEPLUS HUD 0.4

HUD inspirada na organização familiar de jogos sandbox de sobrevivência, mas com identidade visual própria:
- painel de status no canto superior esquerdo;
- corações e fome em linhas separadas;
- hotbar de nove espaços na parte inferior central;
- seleção de espaço com contorno ciano;
- painéis e botões em azul-marinho/ciano com bordas arredondadas;
- controles de toque preservados.

A hotbar é atualmente visual: selecionar espaços muda o destaque, mas ainda não altera o item segurado nem o inventário real.
