# MINEPLUS — teclado e mouse (preparação PS4)

Este pacote acrescenta suporte de entrada no código do projeto para teclado USB/Bluetooth e mouse, além dos controles touchscreen e do mapeamento inicial de gamepad.

## Teclas e mouse

| Entrada | Ação |
|---|---|
| W / A / S / D | Andar |
| Mouse | Girar a câmera (FPS) |
| Clique esquerdo | Atacar com a Aetherblade |
| Clique direito | Minerar ou colocar bloco, conforme modo |
| B | Alternar modo construir |
| E | Interagir/minerar ou colocar conforme modo |
| Espaço | Pular |
| Esc | Soltar o cursor |
| Clique após Esc | Capturar novamente o mouse |

## Observação sobre PS4

O jogo ainda não foi executado em um PS4 por esta entrega. O suporte depende de o runtime/porta do Godot para PS4 expor o teclado e o mouse como eventos de entrada para o jogo. O reconhecimento de dispositivos USB pelo próprio sistema do PS4 não garante, por si só, que uma porta não oficial do motor repasse todos os eventos. Validar no console real e ajustar a captura do cursor/mapeamento se necessário.
