# MINEPLUS — Situação real da adaptação PS4

## Resultado desta etapa (v0.9)
- Corrigido o estado do modo construção para funcionar mesmo se a HUD não estiver carregada.
- O modo construção e a interação agora passam pelo InputMap, permitindo os mesmos comandos no teclado e no controle.
- A HUD expõe métodos públicos `set_build_mode()` e `is_build_mode()`; o jogador não tenta consultar propriedades de `Object` com o operador `in`.
- Mantidos os controles existentes: WASD, Espaço, B, E, mouse e DualShock 4.

## Bloqueio técnico que permanece
O projeto é um jogo Godot 4.3 em GDScript. A OpenOrbis PS4 Toolchain compila programas nativos para PS4 e converte um ELF compatível em `eboot.bin`; ela não importa um projeto Godot, não interpreta GDScript e não fornece, por si só, o motor Godot para PS4.

Para executar este jogo no console, ainda é necessário um porte/runtime Godot 4 para PS4 que inclua, no mínimo:
- parser e runtime de GDScript compatíveis com a versão do projeto;
- SceneTree, física 3D, recursos, shaders e sistema de arquivos;
- backend gráfico e integração de entrada/controle;
- implementação de áudio e temporização compatível com o console.

Sem esse runtime, compilar um `eboot.bin` de demonstração ou um pacote vazio produziria um aplicativo diferente do MINEPLUS. Por isso, esta versão não contém `eboot.bin` nem `.pkg` e não deve ser instalada como jogo.

## Fluxo de build quando o runtime existir
1. Compilar o runtime/porte Godot para PS4 com a toolchain apropriada.
2. Exportar/empacotar os dados do jogo no formato esperado por esse runtime.
3. Gerar o ELF nativo e convertê-lo em `eboot.bin` com `create-eboot`.
4. Criar `param.sfo`, `icon0.png` e o projeto GP4.
5. Gerar o `.pkg` com LibOrbisPkg e testar no hardware de destino.

## Referências técnicas
- OpenOrbis Toolchain: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain
- Guia oficial do projeto sobre criação de homebrew e empacotamento: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/blob/master/docs/MD/Building%20Homebrew.md
