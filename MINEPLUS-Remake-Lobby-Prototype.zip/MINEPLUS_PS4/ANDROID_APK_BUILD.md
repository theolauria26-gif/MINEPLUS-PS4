# MINEPLUS — preparação para APK Android

## O que já está preparado
- Projeto Godot 4.x com renderer Compatibility para maior compatibilidade mobile.
- Controles touchscreen e HUD responsivo no projeto.
- Esta pasta pode ser importada diretamente no Godot Editor.

## O que falta para gerar um APK instalável
1. Abrir o projeto no Godot 4.3 ou versão compatível.
2. Instalar os templates de exportação correspondentes à versão exata do Godot.
3. Instalar/configurar OpenJDK 17 e Android SDK (platform-tools, build-tools e platform Android).
4. Em Editor > Manage Export Templates, instalar os templates.
5. Em Project > Export, adicionar Android, definir package name `com.mineplus.game`, orientação landscape e arquitetura arm64-v8a.
6. Exportar um APK de debug para instalar e testar no Android.

## Importante
Este ambiente de criação não possui Godot, Android SDK, JDK ou dispositivo Android conectado; portanto não é possível afirmar que o APK foi compilado ou testado aqui. O ZIP contém o projeto-fonte e a preparação/documentação, não um APK.
