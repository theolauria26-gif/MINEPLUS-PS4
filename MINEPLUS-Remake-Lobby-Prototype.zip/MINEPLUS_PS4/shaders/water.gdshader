shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 shallow_color : source_color = vec4(0.12, 0.55, 0.72, 0.68);
uniform float wave_scale = 0.18;
uniform float wave_speed = 0.7;

void fragment() {
    vec2 p = UV * 18.0;
    float a = sin(p.x * 1.7 + TIME * wave_speed) * 0.025;
    float b = cos(p.y * 1.35 - TIME * wave_speed * 0.8) * 0.025;
    float ripple = sin((p.x + p.y) * 2.4 + TIME * 1.2) * 0.035;
    ALBEDO = shallow_color.rgb + vec3(a + b + ripple);
    ALPHA = shallow_color.a;
    ROUGHNESS = 0.16;
    METALLIC = 0.12;
}
