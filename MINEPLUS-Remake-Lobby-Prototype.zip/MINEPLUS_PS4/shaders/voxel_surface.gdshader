shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

uniform vec4 base_color : source_color = vec4(0.3, 0.65, 0.25, 1.0);
uniform float roughness_value : hint_range(0.0, 1.0) = 0.9;
uniform float color_variation : hint_range(0.0, 0.15) = 0.035;

varying vec3 world_position;

void vertex() {
    world_position = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
    float grain = fract(sin(dot(floor(world_position * 1.7), vec3(12.9898, 78.233, 37.719))) * 43758.5453);
    float shade = 1.0 + (grain - 0.5) * color_variation;
    ALBEDO = base_color.rgb * shade;
    ROUGHNESS = roughness_value;
    METALLIC = 0.0;
}
