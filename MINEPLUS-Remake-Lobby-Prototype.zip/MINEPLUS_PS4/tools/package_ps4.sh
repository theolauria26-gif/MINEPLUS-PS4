#!/usr/bin/env bash
set -euo pipefail

BUILD_DIR="${1:-./ps4_build}"
TOOLCHAIN="${OO_PS4_TOOLCHAIN:-}"

if [[ -z "$TOOLCHAIN" || ! -d "$TOOLCHAIN" ]]; then
  echo "ERRO: defina OO_PS4_TOOLCHAIN para a pasta da OpenOrbis Toolchain." >&2
  exit 2
fi

for f in "$BUILD_DIR/eboot.bin" "$BUILD_DIR/sce_sys/param.sfo" "$BUILD_DIR/sce_sys/icon0.png"; do
  if [[ ! -f "$f" ]]; then
    echo "ERRO: arquivo obrigatório ausente: $f" >&2
    echo "O pipeline não gera eboot.bin; é necessário um runtime PS4 compatível." >&2
    exit 3
  fi
done

CREATE_GP4="$TOOLCHAIN/bin/linux/create-gp4"
PKG_TOOL="$TOOLCHAIN/bin/linux/PkgTool.Core"
if [[ ! -x "$CREATE_GP4" ]]; then
  echo "ERRO: create-gp4 não encontrado/executável em $CREATE_GP4" >&2
  exit 4
fi
if [[ ! -f "$PKG_TOOL" ]]; then
  echo "ERRO: PkgTool.Core não encontrado em $PKG_TOOL" >&2
  exit 5
fi

CONTENT_ID="IV0000-MNPX00001_00-MINEPLUS00000001"
(
  cd "$BUILD_DIR"
  "$CREATE_GP4" -out pkg.gp4 --content-id="$CONTENT_ID" --files "eboot.bin sce_sys/param.sfo sce_sys/icon0.png"
  dotnet "$PKG_TOOL" pkg_build pkg.gp4 .
)

echo "Processo de empacotamento concluído. Confira o .pkg gerado antes de instalar."
