# Pipeline de PKG — MINEPLUS

Este pipeline é somente a etapa final de empacotamento. Ele **não compila Godot** e não cria `eboot.bin`.

## Estrutura esperada antes de empacotar

Coloque nesta pasta:
- `eboot.bin` — executável PS4 real, produzido por um runtime/porte compatível.
- `sce_sys/param.sfo` — metadados PS4 válidos.
- `sce_sys/icon0.png` — ícone PNG 512x512, 24-bit, sem transparência.

## Uso no Linux com OpenOrbis/LibOrbisPkg

1. Instale e configure a OpenOrbis Toolchain e o LibOrbisPkg.
2. Defina `OO_PS4_TOOLCHAIN` para a pasta da toolchain.
3. Copie os três arquivos acima para uma pasta de build.
4. Execute `tools/package_ps4.sh` a partir da pasta raiz do projeto, passando a pasta de build como primeiro argumento.

Exemplo:
`./tools/package_ps4.sh ./ps4_build`

O script exige `eboot.bin`, `param.sfo` e `icon0.png` e interrompe o processo se algum estiver ausente. Ele não cria arquivos falsos para contornar a ausência do executável.
