extends CanvasLayer

var move_vector := Vector2.ZERO
var jump_requested := false
var build_mode := false
var joystick_touch := -1
var look_touch := -1
var previous_look := Vector2.ZERO
var player: CharacterBody3D
var world: Node3D
var status_label: Label
var selected_slot := 0
var slot_buttons: Array[Button] = []

const SLOT_ITEMS := [
    ["✦", "Espada"],
    ["▰", "Bloco"],
    ["◆", "Cristal"],
    ["▧", "Madeira"],
    ["⬟", "Pedra"],
    ["❖", "Magia"],
    ["◈", "Minério"],
    ["✚", "Poção"],
    ["＋", "Vazio"]
]

func _ready() -> void:
    player = get_parent().get_node("Player")
    world = get_parent()
    _build_ui()

func _style_panel(panel: PanelContainer, fill: Color, edge: Color, radius: int = 13) -> void:
    var style := StyleBoxFlat.new()
    style.bg_color = fill
    style.border_color = edge
    style.set_border_width_all(2)
    style.corner_radius_top_left = radius
    style.corner_radius_top_right = radius
    style.corner_radius_bottom_left = radius
    style.corner_radius_bottom_right = radius
    style.shadow_color = Color(0, 0, 0, 0.28)
    style.shadow_size = 4
    style.shadow_offset = Vector2(0, 2)
    panel.add_theme_stylebox_override("panel", style)

func _build_ui() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    # Top-left survival panel: familiar heart/food readout, with MINEPLUS styling.
    var survival := PanelContainer.new()
    survival.position = Vector2(16, 14)
    survival.custom_minimum_size = Vector2(250, 76)
    _style_panel(survival, Color(0.015, 0.018, 0.025, 0.62), Color(0.72, 0.78, 0.86, 0.58), 14)
    root.add_child(survival)
    var survival_col := VBoxContainer.new()
    survival_col.add_theme_constant_override("separation", 3)
    survival.add_child(survival_col)

    var title := Label.new()
    title.text = "MINEPLUS  •  AVENTURA"
    title.add_theme_font_size_override("font_size", 14)
    title.add_theme_color_override("font_color", Color(0.92, 0.95, 1.0))
    survival_col.add_child(title)

    var hearts := Label.new()
    hearts.text = "♥ ♥ ♥ ♥ ♥ ♥ ♥ ♥ ♥ ♥"
    hearts.add_theme_font_size_override("font_size", 17)
    hearts.add_theme_color_override("font_color", Color(1.0, 0.32, 0.43))
    survival_col.add_child(hearts)

    var hunger := Label.new()
    hunger.text = "◆ ◆ ◆ ◆ ◆ ◆ ◆ ◆ ◆ ◆"
    hunger.add_theme_font_size_override("font_size", 13)
    hunger.add_theme_color_override("font_color", Color(1.0, 0.72, 0.28))
    survival_col.add_child(hunger)

    # Center reticle.
    var reticle := Label.new()
    reticle.text = "⊙"
    reticle.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    reticle.position = Vector2(-10, -20)
    reticle.add_theme_font_size_override("font_size", 25)
    reticle.add_theme_color_override("font_color", Color(0.96, 0.97, 1.0, 0.88))
    root.add_child(reticle)

    # Bottom-center rounded hotbar with nine slots.
    var hotbar := PanelContainer.new()
    hotbar.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    hotbar.position = Vector2(-238, -83)
    hotbar.custom_minimum_size = Vector2(476, 64)
    _style_panel(hotbar, Color(0.025, 0.045, 0.085, 0.91), Color(0.22, 0.68, 0.86, 0.95), 15)
    root.add_child(hotbar)

    var slots := HBoxContainer.new()
    slots.add_theme_constant_override("separation", 4)
    slots.alignment = BoxContainer.ALIGNMENT_CENTER
    hotbar.add_child(slots)

    for i in range(9):
        var slot := Button.new()
        slot.custom_minimum_size = Vector2(48, 48)
        slot.text = SLOT_ITEMS[i][0]
        slot.tooltip_text = SLOT_ITEMS[i][1]
        slot.add_theme_font_size_override("font_size", 23)
        slot.add_theme_color_override("font_color", Color(0.86, 0.95, 1.0))
        var normal := StyleBoxFlat.new()
        normal.bg_color = Color(0.015, 0.018, 0.025, 0.58)
        normal.border_color = Color(0.72, 0.78, 0.86, 0.48)
        normal.set_border_width_all(1)
        normal.corner_radius_top_left = 9
        normal.corner_radius_top_right = 9
        normal.corner_radius_bottom_left = 9
        normal.corner_radius_bottom_right = 9
        slot.add_theme_stylebox_override("normal", normal)
        var pressed := StyleBoxFlat.new()
        pressed.bg_color = Color(0.22, 0.25, 0.30, 0.82)
        pressed.border_color = Color(0.96, 0.97, 1.0, 0.92)
        pressed.set_border_width_all(3)
        pressed.corner_radius_top_left = 9
        pressed.corner_radius_top_right = 9
        pressed.corner_radius_bottom_left = 9
        pressed.corner_radius_bottom_right = 9
        slot.add_theme_stylebox_override("pressed", pressed)
        slot.add_theme_stylebox_override("hover", pressed)
        slot.pressed.connect(_select_slot.bind(i))
        slots.add_child(slot)
        slot_buttons.append(slot)
    _refresh_hotbar()

    # Floating mobile controls, matching the rounded hotbar palette.
    var joystick := Label.new()
    joystick.text = "◉"
    joystick.position = Vector2(40, -155)
    joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    joystick.add_theme_font_size_override("font_size", 72)
    joystick.add_theme_color_override("font_color", Color(0.82, 0.87, 0.94, 0.38))
    root.add_child(joystick)

    _add_button(root, "PULAR", Vector2(-112, -110), Vector2(96, 56), _jump, Control.PRESET_BOTTOM_RIGHT)
    _add_button(root, "ATACAR", Vector2(-222, -176), Vector2(104, 62), _attack, Control.PRESET_BOTTOM_RIGHT)
    _add_button(root, "MINERAR", Vector2(-222, -105), Vector2(104, 54), _mine, Control.PRESET_BOTTOM_RIGHT)
    _add_button(root, "CONSTRUIR", Vector2(18, -88), Vector2(116, 48), _toggle_build, Control.PRESET_BOTTOM_LEFT)

func _refresh_hotbar() -> void:
    for i in range(slot_buttons.size()):
        var slot := slot_buttons[i]
        var style: StyleBoxFlat
        if i == selected_slot:
            style = StyleBoxFlat.new()
            style.bg_color = Color(0.22, 0.25, 0.30, 0.82)
            style.border_color = Color(0.96, 0.97, 1.0, 0.92)
            style.set_border_width_all(3)
        else:
            style = StyleBoxFlat.new()
            style.bg_color = Color(0.015, 0.018, 0.025, 0.58)
            style.border_color = Color(0.72, 0.78, 0.86, 0.48)
            style.set_border_width_all(1)
        style.corner_radius_top_left = 9
        style.corner_radius_top_right = 9
        style.corner_radius_bottom_left = 9
        style.corner_radius_bottom_right = 9
        slot.add_theme_stylebox_override("normal", style)

func _select_slot(index: int) -> void:
    selected_slot = index
    _refresh_hotbar()

func _add_button(parent: Control, label: String, offset: Vector2, size: Vector2, callback: Callable, anchor: int) -> void:
    var b := Button.new()
    b.text = label
    b.set_anchors_preset(anchor)
    b.position = offset
    b.size = size
    b.add_theme_font_size_override("font_size", 15)
    b.add_theme_color_override("font_color", Color(0.96, 0.97, 1.0))
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.008, 0.012, 0.018, 0.62)
    style.border_color = Color(0.78, 0.83, 0.90, 0.62)
    style.set_border_width_all(2)
    style.corner_radius_top_left = 13
    style.corner_radius_top_right = 13
    style.corner_radius_bottom_left = 13
    style.corner_radius_bottom_right = 13
    b.add_theme_stylebox_override("normal", style)
    b.add_theme_stylebox_override("hover", style)
    b.add_theme_stylebox_override("pressed", style)
    b.pressed.connect(callback)
    parent.add_child(b)

func _jump() -> void:
    jump_requested = true

func _attack() -> void:
    if player and player.has_method("attack"):
        player.attack()

func consume_jump() -> bool:
    var result := jump_requested
    jump_requested = false
    return result

func _mine() -> void:
    if player:
        world.interact_from_camera(player.camera, build_mode)

func _toggle_build() -> void:
    set_build_mode(not build_mode)

func set_build_mode(active: bool) -> void:
    build_mode = active

func is_build_mode() -> bool:
    return build_mode

func get_move_vector() -> Vector2:
    return move_vector

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.45 and joystick_touch == -1:
                joystick_touch = event.index
                _update_joystick(event.position)
            elif event.position.x >= get_viewport().get_visible_rect().size.x * 0.45:
                look_touch = event.index
                previous_look = event.position
        else:
            if event.index == joystick_touch:
                joystick_touch = -1
                move_vector = Vector2.ZERO
            if event.index == look_touch:
                look_touch = -1
    elif event is InputEventScreenDrag:
        if event.index == joystick_touch:
            _update_joystick(event.position)
        elif event.index == look_touch and player:
            player.look_by_drag(event.position - previous_look)
            previous_look = event.position

func _update_joystick(pos: Vector2) -> void:
    var viewport_size := get_viewport().get_visible_rect().size
    var center := Vector2(125.0, viewport_size.y - 125.0)
    move_vector = ((pos - center) / 75.0).limit_length()
