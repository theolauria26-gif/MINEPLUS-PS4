extends Control

const GAME_SCENE := "res://scenes/Main.tscn"
var world_view: SubViewport
var camera: Camera3D
var status_label: Label
var clock := 0.0

func _ready() -> void:
    _build_backdrop()
    _build_ui()

func _process(delta: float) -> void:
    clock += delta
    if is_instance_valid(camera):
        camera.position.x = sin(clock * 0.10) * 0.5
        camera.position.y = 7.0 + sin(clock * 0.18) * 0.15
        camera.look_at(Vector3(0, 2.5, 0))

func _build_backdrop() -> void:
    var container := SubViewportContainer.new()
    container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    container.stretch = true
    container.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(container)
    world_view = SubViewport.new()
    world_view.size = Vector2i(1280, 720)
    world_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    container.add_child(world_view)
    var world := Node3D.new()
    world_view.add_child(world)
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.025, 0.045, 0.09)
    sky_mat.sky_horizon_color = Color(0.22, 0.12, 0.075)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.42, 0.48, 0.62)
    env.ambient_light_energy = 0.65
    env_node.environment = env
    world.add_child(env_node)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-42, -28, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    world.add_child(sun)
    camera = Camera3D.new()
    camera.position = Vector3(0, 7, 13)
    camera.fov = 55
    world.add_child(camera)
    camera.look_at(Vector3(0, 2.5, 0))
    var stone := _material(Color(0.22, 0.24, 0.27))
    var dark := _material(Color(0.10, 0.12, 0.15))
    var warm := _material(Color(0.34, 0.22, 0.14))
    var blue := _material(Color(0.08, 0.66, 0.95), 1.8)
    var orange := _material(Color(1.0, 0.27, 0.035), 2.2)
    for x in range(-10, 11):
        for z in range(-8, 5):
            _block(world, Vector3(x, -1, z), Vector3.ONE, stone)
        for y in range(0, 7):
            if x < -8 or x > 8 or y > 5:
                _block(world, Vector3(x, y, -7), Vector3.ONE, dark)
    for x in [-7, -6, 6, 7]:
        for y in range(0, 5):
            _block(world, Vector3(x, y, -2), Vector3.ONE, warm)
    for x in [-5, -4, 4, 5]:
        _block(world, Vector3(x, 0, -3), Vector3(1, 0.18, 1), orange)
    for p in [Vector3(-7, 2, -1), Vector3(7, 2, -1), Vector3(0, 3, -6)]:
        _block(world, p, Vector3(0.28, 1.0, 0.28), blue)
        _block(world, p + Vector3(0, 0.7, 0), Vector3(0.55, 0.25, 0.55), blue)
    for i in range(12):
        _block(world, Vector3(-8.0 + i * 1.45, -0.15, 2.0 + sin(float(i)) * 0.7), Vector3(1.3, 0.35, 1.1), dark)

func _material(color: Color, glow := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.88
    if glow > 0.0:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = glow
    return m

func _block(parent: Node3D, pos: Vector3, size: Vector3, material: Material) -> void:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.position = pos
    mesh.material_override = material
    parent.add_child(mesh)

func _build_ui() -> void:
    var tint := ColorRect.new()
    tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    tint.color = Color(0.015, 0.02, 0.035, 0.42)
    tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(tint)
    var header := VBoxContainer.new()
    header.set_anchors_preset(Control.PRESET_TOP_WIDE)
    header.offset_top = 18
    add_child(header)
    var logo := Label.new()
    logo.text = "MINEPLUS"
    logo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    logo.add_theme_font_size_override("font_size", 48)
    logo.add_theme_color_override("font_color", Color(0.94, 0.96, 1))
    header.add_child(logo)
    var tagline := Label.new()
    tagline.text = "EXPLORE  •  CONSTRUA  •  SOBREVIVA"
    tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    tagline.add_theme_font_size_override("font_size", 13)
    tagline.add_theme_color_override("font_color", Color(0.48, 0.82, 0.98))
    header.add_child(tagline)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    center.offset_top = 100
    center.offset_bottom = -20
    add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(340, 0)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.035, 0.045, 0.06, 0.88)
    style.border_color = Color(0.45, 0.58, 0.68, 0.62)
    style.set_border_width_all(1)
    style.set_corner_radius_all(12)
    style.content_margin_left = 18
    style.content_margin_right = 18
    style.content_margin_top = 18
    style.content_margin_bottom = 18
    panel.add_theme_stylebox_override("panel", style)
    center.add_child(panel)
    var list := VBoxContainer.new()
    list.add_theme_constant_override("separation", 9)
    panel.add_child(list)
    _button(list, "JOGAR", _start_game, true)
    _button(list, "MULTIJOGADOR", func(): _status("Multijogador será implementado."))
    _button(list, "PERSONALIZAR SKIN", func(): _status("Editor de skins em desenvolvimento."))
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 9)
    list.add_child(row)
    _button(row, "MUNDOS", func(): _status("Gerenciador de mundos em desenvolvimento."), false, true)
    _button(row, "LOJA", func(): _status("Cosméticos e loja em desenvolvimento."), false, true)
    _button(list, "CONFIGURAÇÕES", func(): _status("Configurações em desenvolvimento."))
    _button(list, "SAIR", func(): get_tree().quit())
    status_label = Label.new()
    status_label.text = "ALPHA  •  MINEPLUS"
    status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status_label.add_theme_font_size_override("font_size", 11)
    status_label.add_theme_color_override("font_color", Color(0.72, 0.77, 0.84))
    list.add_child(status_label)
    var footer := Label.new()
    footer.text = "MINEPLUS  •  FEITO PARA EXPLORADORES"
    footer.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    footer.offset_top = -30
    footer.offset_bottom = -8
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    footer.add_theme_font_size_override("font_size", 10)
    footer.add_theme_color_override("font_color", Color(0.78, 0.82, 0.88, 0.8))
    add_child(footer)

func _button(parent: Node, caption: String, callback: Callable, primary := false, compact := false) -> void:
    var b := Button.new()
    b.text = caption
    b.custom_minimum_size = Vector2(0, 44 if not compact else 40)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.08, 0.34, 0.48, 0.96) if primary else Color(0.10, 0.13, 0.17, 0.94)
    normal.border_color = Color(0.32, 0.40, 0.48, 0.9)
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(7)
    var hover := normal.duplicate()
    hover.bg_color = Color(0.10, 0.48, 0.65, 1) if primary else Color(0.16, 0.23, 0.29, 1)
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("focus", hover)
    b.add_theme_color_override("font_color", Color(0.93, 0.96, 1))
    b.add_theme_font_size_override("font_size", 14)
    b.pressed.connect(callback)
    parent.add_child(b)

func _start_game() -> void:
    get_tree().change_scene_to_file(GAME_SCENE)

func _status(message: String) -> void:
    status_label.text = message
