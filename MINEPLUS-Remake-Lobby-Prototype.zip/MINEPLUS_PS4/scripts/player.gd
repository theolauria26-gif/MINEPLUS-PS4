extends CharacterBody3D

@export var move_speed := 5.0
@export var jump_velocity := 5.0
@export var look_sensitivity := 0.004
@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var hud: Node
var mouse_captured := false
var weapon_root: Node3D
var swing_tween: Tween
var attack_cooldown := 0.0
var health := 100
var stamina := 100.0
var gamepad_look_sensitivity := 2.2
var _right_trigger_was_pressed := false
var build_mode_active := false

func _ready() -> void:
    for action in ["attack", "jump", "interact", "toggle_build", "move_left", "move_right", "move_forward", "move_back"]:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
    if not OS.has_feature("mobile"):
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        mouse_captured = true
    hud = get_tree().current_scene.get_node_or_null("TouchHUD")
    _create_first_person_weapon()
    _setup_keyboard_mouse_actions()
    _setup_gamepad_actions()

func _add_key_binding(action: String, key: Key) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    var event := InputEventKey.new()
    event.physical_keycode = key
    InputMap.action_add_event(action, event)

func _setup_keyboard_mouse_actions() -> void:
    # Keyboard layout: WASD, Space, B. Works alongside the DualShock mappings.
    for action in ["move_forward", "move_back", "move_left", "move_right",
                   "jump", "toggle_build", "interact"]:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
    _add_key_binding("move_forward", KEY_W)
    _add_key_binding("move_back", KEY_S)
    _add_key_binding("move_left", KEY_A)
    _add_key_binding("move_right", KEY_D)
    _add_key_binding("jump", KEY_SPACE)
    _add_key_binding("toggle_build", KEY_B)
    _add_key_binding("interact", KEY_E)

func _setup_gamepad_actions() -> void:
    # DualShock 4 / SDL-style standard mapping. Device-specific layouts may vary.
    for action in ["attack", "jump", "toggle_build", "interact"]:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
    var jump_event := InputEventJoypadButton.new()
    jump_event.button_index = JOY_BUTTON_A
    InputMap.action_add_event("jump", jump_event)
    var attack_event := InputEventJoypadButton.new()
    attack_event.button_index = JOY_BUTTON_X
    InputMap.action_add_event("attack", attack_event)
    var build_event := InputEventJoypadButton.new()
    build_event.button_index = JOY_BUTTON_Y
    InputMap.action_add_event("toggle_build", build_event)
    var interact_event := InputEventJoypadButton.new()
    interact_event.button_index = JOY_BUTTON_B
    InputMap.action_add_event("interact", interact_event)

func _physics_process(delta: float) -> void:
    _read_gamepad_look(delta)
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    var input := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    if hud and hud.has_method("get_move_vector"):
        var touch_input: Vector2 = hud.get_move_vector()
        if touch_input.length() > input.length():
            input = touch_input
    input = input.limit_length()
    var direction := (transform.basis * Vector3(input.x, 0, input.y)).normalized()
    if direction:
        velocity.x = direction.x * move_speed
        velocity.z = direction.z * move_speed
    else:
        velocity.x = move_toward(velocity.x, 0, move_speed)
        velocity.z = move_toward(velocity.z, 0, move_speed)
    if Input.is_action_just_pressed("jump") or (hud and hud.has_method("consume_jump") and hud.consume_jump()):
        if is_on_floor():
            velocity.y = jump_velocity
    if Input.is_action_just_pressed("attack"):
        attack()
    if Input.is_action_just_pressed("toggle_build"):
        _toggle_build_mode()
    if Input.is_action_just_pressed("interact"):
        _interact_or_mine()
    move_and_slide()

func _read_gamepad_look(delta: float) -> void:
    var pads := Input.get_connected_joypads()
    if pads.is_empty():
        return
    var device := pads[0]
    var look := Vector2(
        Input.get_joy_axis(device, JOY_AXIS_RIGHT_X),
        Input.get_joy_axis(device, JOY_AXIS_RIGHT_Y)
    )
    if look.length() > 0.16:
        rotate_y(-look.x * gamepad_look_sensitivity * delta)
        head.rotate_x(-look.y * gamepad_look_sensitivity * delta)
        head.rotation.x = clampf(head.rotation.x, deg_to_rad(-85), deg_to_rad(85))

func _create_first_person_weapon() -> void:
    weapon_root = Node3D.new()
    weapon_root.name = "AetherbladeViewmodel"
    weapon_root.position = Vector3(0.48, -0.43, -0.78)
    weapon_root.rotation_degrees = Vector3(-8, -18, -12)
    camera.add_child(weapon_root)

    var grip := _weapon_part("Grip", Vector3(0.075, 0.34, 0.075), Color(0.20, 0.12, 0.10), Vector3(0, -0.22, 0))
    grip.rotation_degrees.z = -12
    _weapon_part("Pommel", Vector3(0.14, 0.10, 0.14), Color(0.88, 0.58, 0.18), Vector3(0, -0.40, 0))
    _weapon_part("Crossguard", Vector3(0.42, 0.075, 0.11), Color(0.91, 0.63, 0.20), Vector3(0, -0.02, 0))
    var blade := _weapon_part("CrystalBlade", Vector3(0.19, 0.78, 0.075), Color(0.12, 0.83, 1.0), Vector3(0, 0.40, 0))
    blade.rotation_degrees.z = 0
    var rune := _weapon_part("Rune", Vector3(0.055, 0.30, 0.025), Color(1.0, 0.78, 0.24), Vector3(0, 0.40, -0.045))
    rune.material_override = _emissive_material(Color(1.0, 0.72, 0.20))
    blade.material_override = _emissive_material(Color(0.08, 0.72, 1.0))
    _weapon_part("GuardGem", Vector3(0.12, 0.12, 0.12), Color(0.25, 0.95, 1.0), Vector3(0, -0.01, -0.07)).material_override = _emissive_material(Color(0.1, 0.9, 1.0))

    # A stylized armored forearm makes the weapon grip visibly different from a floating sword.
    var sleeve := _weapon_part("Forearm", Vector3(0.22, 0.42, 0.25), Color(0.17, 0.22, 0.34), Vector3(-0.02, -0.43, 0.13))
    sleeve.rotation_degrees.z = -18
    var cuff := _weapon_part("GoldCuff", Vector3(0.25, 0.09, 0.27), Color(0.82, 0.55, 0.18), Vector3(-0.02, -0.25, 0.08))
    cuff.rotation_degrees.z = -18

func _weapon_part(part_name: String, size: Vector3, color: Color, offset: Vector3) -> MeshInstance3D:
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = part_name
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.metallic = 0.55
    material.roughness = 0.25
    material.emission_enabled = color.b > 0.7 and color.g > 0.5
    material.emission = color * 0.35
    mesh_instance.material_override = material
    mesh_instance.position = offset
    weapon_root.add_child(mesh_instance)
    return mesh_instance

func _emissive_material(color: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.emission_enabled = true
    material.emission = color
    material.emission_energy_multiplier = 1.8
    material.metallic = 0.35
    return material

func attack() -> void:
    if attack_cooldown > 0.0:
        return
    attack_cooldown = 0.48
    stamina = maxf(0.0, stamina - 8.0)
    if swing_tween and swing_tween.is_running():
        swing_tween.kill()
    weapon_root.rotation_degrees = Vector3(-8, -18, -12)
    weapon_root.position = Vector3(0.48, -0.43, -0.78)
    swing_tween = create_tween()
    swing_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    swing_tween.tween_property(weapon_root, "rotation_degrees", Vector3(-48, 28, 62), 0.12)
    swing_tween.parallel().tween_property(weapon_root, "position", Vector3(0.34, -0.30, -0.68), 0.12)
    swing_tween.tween_property(weapon_root, "rotation_degrees", Vector3(12, -8, -28), 0.10)
    swing_tween.parallel().tween_property(weapon_root, "position", Vector3(0.50, -0.40, -0.78), 0.10)
    swing_tween.tween_property(weapon_root, "rotation_degrees", Vector3(-8, -18, -12), 0.18)
    swing_tween.parallel().tween_property(weapon_root, "position", Vector3(0.48, -0.43, -0.78), 0.18)
    _try_melee_hit()

func _try_melee_hit() -> void:
    var from := camera.global_position
    var to := from + (-camera.global_transform.basis.z * 3.0)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [self]
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        return
    var target := hit.get("collider") as Node
    if target and target.has_method("take_damage"):
        target.take_damage(28, global_position)

func look_by_drag(delta_position: Vector2) -> void:
    rotate_y(-delta_position.x * look_sensitivity)
    head.rotate_x(-delta_position.y * look_sensitivity)
    head.rotation.x = clampf(head.rotation.x, deg_to_rad(-85), deg_to_rad(85))

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and mouse_captured:
        look_by_drag(event.relative)
    elif event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
            mouse_captured = false
    elif event is InputEventMouseButton and event.pressed:
        if not mouse_captured:
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
            mouse_captured = true
        elif event.button_index == MOUSE_BUTTON_LEFT:
            attack()
        elif event.button_index == MOUSE_BUTTON_RIGHT:
            _interact_or_mine()

func _toggle_build_mode() -> void:
    build_mode_active = not build_mode_active
    if hud and hud.has_method("set_build_mode"):
        hud.set_build_mode(build_mode_active)

func _interact_or_mine() -> void:
    var world := get_tree().current_scene
    if world and world.has_method("interact_from_camera"):
        var active_mode := build_mode_active
        if hud and hud.has_method("is_build_mode"):
            active_mode = hud.is_build_mode()
        world.interact_from_camera(camera, active_mode)
