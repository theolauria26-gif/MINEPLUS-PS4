extends CharacterBody3D

@export var max_health := 56
@export var move_speed := 1.8
var health := 56
var target: Node3D
var attack_timer := 0.0
var hurt_flash := 0.0
var body_material: StandardMaterial3D

func _ready() -> void:
    health = max_health
    target = get_tree().current_scene.get_node_or_null("Player")
    _build_creature()

func _build_creature() -> void:
    body_material = StandardMaterial3D.new()
    body_material.albedo_color = Color(0.34, 0.12, 0.48)
    body_material.metallic = 0.25
    body_material.roughness = 0.42
    var body_mesh := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.38
    capsule.height = 1.35
    body_mesh.mesh = capsule
    body_mesh.material_override = body_material
    body_mesh.position.y = 0.82
    add_child(body_mesh)

    var head_mesh := MeshInstance3D.new()
    var head := SphereMesh.new()
    head.radius = 0.30
    head.height = 0.60
    head_mesh.mesh = head
    head_mesh.position = Vector3(0, 1.58, -0.04)
    head_mesh.material_override = body_material
    add_child(head_mesh)

    var eye_material := StandardMaterial3D.new()
    eye_material.albedo_color = Color(0.2, 0.95, 1.0)
    eye_material.emission_enabled = true
    eye_material.emission = Color(0.1, 0.8, 1.0)
    for side in [-1.0, 1.0]:
        var eye := MeshInstance3D.new()
        var eye_mesh := SphereMesh.new()
        eye_mesh.radius = 0.055
        eye_mesh.height = 0.11
        eye.mesh = eye_mesh
        eye.material_override = eye_material
        eye.position = Vector3(side * 0.12, 1.62, -0.30)
        add_child(eye)

    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.36
    shape.height = 1.65
    collision.shape = shape
    collision.position.y = 0.82
    add_child(collision)

func _physics_process(delta: float) -> void:
    if not is_instance_valid(target):
        return
    attack_timer = maxf(0.0, attack_timer - delta)
    hurt_flash = maxf(0.0, hurt_flash - delta)
    if hurt_flash > 0.0:
        body_material.albedo_color = Color(1.0, 0.28, 0.22)
    else:
        body_material.albedo_color = Color(0.34, 0.12, 0.48)
    var offset := target.global_position - global_position
    offset.y = 0
    if offset.length() > 1.6 and offset.length() < 15.0:
        var direction := offset.normalized()
        velocity.x = direction.x * move_speed
        velocity.z = direction.z * move_speed
        look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z), Vector3.UP)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 5.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 5.0 * delta)
    if not is_on_floor():
        velocity.y -= float(ProjectSettings.get_setting("physics/3d/default_gravity")) * delta
    move_and_slide()

func take_damage(amount: int, _source_position: Vector3) -> void:
    health -= amount
    hurt_flash = 0.16
    var push := (global_position - target.global_position).normalized()
    velocity.x = push.x * 4.5
    velocity.z = push.z * 4.5
    if health <= 0:
        queue_free()
