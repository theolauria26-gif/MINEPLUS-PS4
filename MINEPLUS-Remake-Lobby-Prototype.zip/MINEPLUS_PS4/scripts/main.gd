extends Node3D

const WORLD_SIZE := 32
const MAX_HEIGHT := 7
const WATER_LEVEL := 2

var blocks: Dictionary = {}
var block_mesh := BoxMesh.new()
var block_materials: Array[ShaderMaterial] = []
var sun: DirectionalLight3D
var environment: WorldEnvironment
var day_clock := 0.22
var day_speed := 0.006

func _ready() -> void:
    environment = $WorldEnvironment
    sun = $DirectionalLight3D
    _make_materials()
    _generate_world()
    _create_water()
    _create_decorations()
    _create_structures()
    _spawn_shade_stalkers()


func _spawn_shade_stalkers() -> void:
    var enemy_script := load("res://scripts/enemy.gd")
    var positions := [Vector3(11, 8, 9), Vector3(19, 8, 16), Vector3(25, 8, 8)]
    for pos in positions:
        var enemy := CharacterBody3D.new()
        enemy.name = "ShadeStalker"
        enemy.set_script(enemy_script)
        enemy.position = pos
        add_child(enemy)

func _make_materials() -> void:
    var colors := [
        Color(0.27, 0.66, 0.20), # grass
        Color(0.39, 0.25, 0.14), # dirt
        Color(0.43, 0.46, 0.49), # stone
        Color(0.36, 0.23, 0.12), # wood
        Color(0.16, 0.48, 0.16), # leaves
        Color(0.72, 0.70, 0.62)  # sand
    ]
    for c in colors:
        var shader := load("res://shaders/voxel_surface.gdshader") as Shader
        var mat := ShaderMaterial.new()
        mat.shader = shader
        mat.set_shader_parameter("base_color", c)
        mat.set_shader_parameter("roughness_value", 0.92)
        block_materials.append(mat)

func _generate_world() -> void:
    for x in range(WORLD_SIZE):
        for z in range(WORLD_SIZE):
            var wave := sin(float(x) * 0.24) * cos(float(z) * 0.19)
            var detail := sin(float(x + z) * 0.51) * 0.45
            var h := clampi(3 + int(round(wave * 2.0 + detail)), 1, MAX_HEIGHT)
            for y in range(h):
                var kind := 2
                if y == h - 1:
                    kind = 0 if h > WATER_LEVEL else 5
                elif y >= h - 3:
                    kind = 1
                place_block(Vector3i(x, y, z), kind)

func _create_water() -> void:
    var water := MeshInstance3D.new()
    water.name = "Water"
    var plane := PlaneMesh.new()
    plane.size = Vector2(WORLD_SIZE + 8, WORLD_SIZE + 8)
    water.mesh = plane
    water.position = Vector3(WORLD_SIZE * 0.5, WATER_LEVEL + 0.18, WORLD_SIZE * 0.5)
    var mat := ShaderMaterial.new()
    mat.shader = load("res://shaders/water.gdshader")
    water.material_override = mat
    add_child(water)

func _create_decorations() -> void:
    # Deterministic tree placement, avoiding the spawn clearing.
    for x in range(3, WORLD_SIZE - 2, 5):
        for z in range(3, WORLD_SIZE - 2, 6):
            if abs(x - 5) + abs(z - 5) < 7:
                continue
            var ground := _surface_height(x, z)
            if ground <= WATER_LEVEL:
                continue
            for y in range(1, 4):
                place_block(Vector3i(x, ground + y, z), 3)
            for ox in range(-2, 3):
                for oz in range(-2, 3):
                    for oy in range(2, 5):
                        if abs(ox) + abs(oz) + abs(oy - 3) <= 4:
                            place_block(Vector3i(x + ox, ground + oy, z + oz), 4)


func _create_structures() -> void:
    _build_wayfarer_cabin(14, 20)
    _build_ancient_ruin(24, 9)
    _build_stone_shrine(7, 25)

func _build_wayfarer_cabin(x: int, z: int) -> void:
    var y := _surface_height(x + 2, z + 2)
    # Raised stone foundation and wooden cabin walls.
    for dx in range(6):
        for dz in range(6):
            place_block(Vector3i(x + dx, y, z + dz), 2)
    for dy in range(1, 4):
        for dx in range(6):
            for dz in range(6):
                var edge := dx == 0 or dx == 5 or dz == 0 or dz == 5
                if not edge:
                    continue
                # Front doorway and side windows remain open.
                if dz == 0 and dx == 2 and dy <= 2:
                    continue
                if (dx == 0 or dx == 5) and dz == 2 and dy == 2:
                    continue
                place_block(Vector3i(x + dx, y + dy, z + dz), 3)
    # Dark stone roof with a slight overhang.
    for dx in range(-1, 7):
        for dz in range(-1, 7):
            place_block(Vector3i(x + dx, y + 4, z + dz), 2)
    # A bright marker above the doorway.
    place_block(Vector3i(x + 2, y + 3, z), 5)

func _build_ancient_ruin(x: int, z: int) -> void:
    var y := _surface_height(x + 2, z + 2)
    for dx in range(7):
        for dz in range(7):
            if dx == 0 or dx == 6 or dz == 0 or dz == 6:
                place_block(Vector3i(x + dx, y, z + dz), 2)
    # Broken corner pillars and a partial arch.
    for dy in range(1, 4):
        place_block(Vector3i(x, y + dy, z), 2)
        place_block(Vector3i(x + 6, y + dy, z), 2)
        if dy <= 2:
            place_block(Vector3i(x, y + dy, z + 6), 2)
    for dx in range(1, 6):
        if dx != 3:
            place_block(Vector3i(x + dx, y + 4, z), 2)
    # Central altar.
    place_block(Vector3i(x + 3, y + 1, z + 3), 2)
    place_block(Vector3i(x + 3, y + 2, z + 3), 5)

func _build_stone_shrine(x: int, z: int) -> void:
    var y := _surface_height(x + 1, z + 1)
    for dx in range(4):
        for dz in range(4):
            place_block(Vector3i(x + dx, y, z + dz), 2)
    for dx in [0, 3]:
        for dz in [0, 3]:
            for dy in range(1, 4):
                place_block(Vector3i(x + dx, y + dy, z + dz), 2)
    place_block(Vector3i(x + 1, y + 1, z + 1), 5)

func _surface_height(x: int, z: int) -> int:
    var wave := sin(float(x) * 0.24) * cos(float(z) * 0.19)
    var detail := sin(float(x + z) * 0.51) * 0.45
    return clampi(3 + int(round(wave * 2.0 + detail)), 1, MAX_HEIGHT)

func _process(delta: float) -> void:
    day_clock = fposmod(day_clock + delta * day_speed, 1.0)
    var angle := day_clock * TAU
    sun.rotation = Vector3(deg_to_rad(-55.0) * sin(angle), 0.0, angle)
    var daylight := clampf(sin(angle) * 0.8 + 0.25, 0.08, 1.0)
    sun.light_energy = daylight * 1.35
    var env := environment.environment
    env.ambient_light_energy = 0.18 + daylight * 0.72
    env.background_color = Color(0.025, 0.045, 0.10).lerp(Color(0.42, 0.68, 0.90), daylight)

func place_block(cell: Vector3i, kind: int, _update_data := true) -> void:
    if blocks.has(cell):
        return
    var body := StaticBody3D.new()
    body.name = "Block_%d_%d_%d" % [cell.x, cell.y, cell.z]
    body.position = Vector3(cell) + Vector3.ONE * 0.5
    body.set_meta("cell", cell)
    body.set_meta("kind", kind)

    var mesh_instance := MeshInstance3D.new()
    block_mesh.size = Vector3.ONE
    mesh_instance.mesh = block_mesh
    mesh_instance.material_override = block_materials[clampi(kind, 0, block_materials.size() - 1)]
    body.add_child(mesh_instance)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3.ONE
    collision.shape = shape
    body.add_child(collision)

    add_child(body)
    blocks[cell] = body

func remove_block(cell: Vector3i) -> void:
    if not blocks.has(cell):
        return
    var node: Node = blocks[cell]
    blocks.erase(cell)
    node.queue_free()

func interact_from_camera(camera: Camera3D, build_mode: bool) -> void:
    var from := camera.global_position
    var to := from + (-camera.global_transform.basis.z * 6.0)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        return
    var collider := hit.get("collider") as Node
    if collider == null or not collider.has_meta("cell"):
        return
    var cell: Vector3i = collider.get_meta("cell")
    if build_mode:
        var normal: Vector3 = hit.get("normal")
        var target := cell + Vector3i(roundi(normal.x), roundi(normal.y), roundi(normal.z))
        if not blocks.has(target):
            place_block(target, 0)
    else:
        remove_block(cell)
