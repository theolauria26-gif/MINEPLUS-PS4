# Próxima etapa obrigatória — runtime PS4

Não há conversão automática de Godot 4.3/GDScript para OpenOrbis. A etapa seguinte precisa começar pela obtenção ou desenvolvimento de um runtime Godot 4 compatível com PS4. Só depois disso faz sentido integrar o projeto MINEPLUS e produzir um EBOOT/PKG.

## Critérios para aceitar um runtime
- Inicializa no firmware alvo com HEN/GoldHEN sem depender de arquivos externos não documentados.
- Carrega uma cena Godot simples e executa GDScript.
- Desenha uma cena 3D com câmera, malhas, materiais e shader.
- Lê DualShock 4 e, se suportado pela camada SDL/input, teclado e mouse USB.
- Carrega os recursos do jogo a partir do diretório de dados empacotado.

## Não confundir
OpenOrbis + LibOrbisPkg são a cadeia nativa de compilação/empacotamento. Não substituem o motor do jogo. O arquivo `.pkg` só deve ser gerado depois que existir um `eboot.bin` real, construído a partir do runtime e do jogo.
