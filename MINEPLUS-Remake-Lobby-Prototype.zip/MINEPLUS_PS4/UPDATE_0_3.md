# MINEPLUS 0.3 — combate e identidade visual

## Novidades no código
- Aetherblade em primeira pessoa, com empunhadura, antebraço blindado, guarda dourada e lâmina cristalina emissiva.
- Animação de golpe com arco, avanço e retorno da arma.
- Ataque corpo a corpo com alcance de 3 unidades, recarga e dano de 28.
- Três Shade Stalkers roxos com olhos luminosos, 56 pontos de vida, perseguição simples e reação ao dano.
- HUD redesenhada em tons azul-ciano e dourado, com botão GOLPE separado de MINERAR.
- Botões ancorados às bordas para se adaptarem melhor a diferentes proporções de tela.

## Limitações conhecidas
- Esta é uma atualização do projeto-fonte Godot, não um APK compilado.
- Não foi possível executar ou validar o projeto em um dispositivo Android neste ambiente.
- Os inimigos ainda não atacam o jogador; nesta versão perseguem e recebem dano.
- O HUD mostra valores ilustrativos de vitalidade/foco; sistema completo de atributos ainda será implementado.
- Os inimigos são protótipos geométricos, ainda sem modelos/rigs animados ou áudio.
