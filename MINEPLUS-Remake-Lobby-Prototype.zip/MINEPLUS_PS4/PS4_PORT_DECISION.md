# MINEPLUS — decisão técnica para PS4 (v1.0)

## O que a pesquisa confirmou

1. O Godot não fornece templates oficiais de exportação para PS4. A documentação do Godot 4.5 informa que consoles precisam de SDK e templates específicos; cita empresas terceiras que oferecem portabilidade de Godot para PlayStation 4.
2. A OpenOrbis é uma toolchain de homebrew nativo para PS4. Ela compila código nativo e transforma um ELF compatível em `eboot.bin`; ela não converte GDScript nem executa um projeto Godot por conta própria.
3. Portanto, há duas rotas distintas:
   - **Rota Godot:** obter um porte/runtime Godot para PS4 e os templates adequados por meio de um fornecedor que ofereça PS4. É a rota que preserva melhor o projeto atual em GDScript.
   - **Rota OpenOrbis nativa:** reimplementar o jogo em C/C++ usando bibliotecas suportadas pela toolchain. Isso não é uma conversão automática e exige reescrever gameplay, renderização, física, UI, áudio e recursos.

## Decisão para este projeto

Como o MINEPLUS atual já está em Godot 4.3 e possui scripts, cenas e shaders, a rota tecnicamente mais econômica é preservar o projeto e procurar um runtime/serviço de porte Godot para PS4. A rota OpenOrbis nativa fica como alternativa de reimplementação, não como exportação direta.

## O que esta versão entrega

- Mantém o projeto Godot e os controles da v0.9.
- Adiciona um script de empacotamento para uso futuro, quando existir um `eboot.bin` real.
- Documenta os pré-requisitos e bloqueios de cada rota.

## O que não foi produzido

- Não há runtime Godot PS4 incluído.
- Não há `eboot.bin`.
- Não há `param.sfo` final nem `.pkg`.
- Nenhum teste foi executado em PS4.

## Referências

- Godot 4.5 — Console support: https://docs.godotengine.org/en/4.5/tutorials/platform/consoles.html
- OpenOrbis Toolchain: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain
- OpenOrbis — Building Homebrew: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/blob/master/docs/MD/Building%20Homebrew.md
