# MINEPLUS — Android voxel sandbox prototype

Projeto-fonte Godot 4, preparado para começar e testar em Android.

## Conteúdo incluído
- Terreno voxel procedural com relevo.
- Blocos de grama, terra, pedra, madeira, folhas e areia.
- Árvores geradas proceduralmente.
- Água com shader animado.
- Shader de superfície voxel com variação procedural sutil.
- Ciclo dia/noite com variação de luz e céu.
- Personagem 3D, gravidade, movimento, câmera em primeira pessoa.
- Controles touchscreen: movimento, olhar, pulo, mineração e construção.
- Controles básicos de teclado e mouse no desktop.

## Abrir no Android
1. Instale o Godot Editor para Android por uma fonte oficial.
2. Extraia o ZIP numa pasta do dispositivo.
3. Importe a pasta do projeto no Godot e abra `scenes/Main.tscn`.
4. Execute a cena principal.

## Estado real
Isto é um protótipo de código-fonte, não um jogo comercial final. Não foi compilado em APK/AAB nem validado em aparelho físico nesta sessão. O desempenho ainda precisa ser medido no dispositivo-alvo.

## Limitações técnicas atuais
- Os blocos ainda são nós individuais; mundos grandes exigirão chunks e meshing combinado.
- A água é visual e não tem física de natação.
- Ainda não há inventário persistente, salvamento/carregamento de mundo, criaturas, combate ou áudio.
- O shader de água e iluminação devem ser ajustados conforme o GPU do celular.

## Próxima grande revisão técnica
Migrar o terreno para chunks com mesh combinado, adicionar salvamento de mundo e sistema de inventário antes de expandir o tamanho do mapa.
