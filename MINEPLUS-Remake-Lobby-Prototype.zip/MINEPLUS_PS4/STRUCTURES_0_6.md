# MINEPLUS 0.6 — World Structures

Esta atualização adiciona três pontos de interesse gerados no mapa:

- Cabana do Viajante: fundação de pedra, paredes de madeira, porta, janelas e telhado.
- Ruínas Antigas: perímetro de pedra, pilares quebrados e altar central.
- Pequeno Santuário: base elevada, quatro pilares e um marcador no centro.

As estruturas são montadas com os blocos existentes e aparecem automaticamente ao gerar o mundo. Elas ainda são estruturas estáticas: portas funcionais, baús, loot, NPCs e interiores decorados ficam para etapas posteriores.
