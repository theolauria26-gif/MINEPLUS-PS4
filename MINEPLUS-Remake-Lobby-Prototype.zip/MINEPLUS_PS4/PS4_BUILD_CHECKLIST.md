# MINEPLUS — Checklist de compilação PS4

## Estado atual
- [x] Projeto Godot 4.3 organizado
- [x] Controles base de DualShock 4
- [x] Controles de teclado e mouse no código
- [x] Modo construção com estado compartilhado entre jogador e HUD
- [ ] Runtime/porte Godot 4 funcional para PS4
- [ ] Exportação dos recursos para o runtime PS4
- [ ] ELF nativo compilado
- [ ] `eboot.bin` gerado
- [ ] `param.sfo` e `icon0.png` preparados
- [ ] `.pkg` criado com LibOrbisPkg
- [ ] Instalação e teste no PS4 com firmware/HEN de destino

## Regra
Não marcar as etapas pendentes como concluídas. A OpenOrbis Toolchain não converte diretamente GDScript/Godot em executável PS4. Ver `PS4_RUNTIME_STATUS.md` antes de iniciar um build.
