# MINEPLUS — direção do remake

## Lobby adicionado
- Menu principal com cenário 3D procedural de ruínas subterrâneas.
- Iluminação âmbar de lava e cristais ciano.
- Logo MINEPLUS e botões escuros translúcidos com bordas arredondadas.
- Entradas para Jogar, Multijogador, Personalizar Skin, Mundos, Loja, Configurações e Sair.
- Jogar abre a cena atual `Main.tscn`.

## Direção visual
- Identidade própria: carvão/preto translúcido, aço azulado e ciano; luz âmbar no mundo.
- Texturas voxel estilizadas com variação por face, detalhes e desgaste.
- Skins 3D, acessórios e animações de idle, andar, correr, pular, atacar e receber dano.
- Interface adaptável: toque no Android; teclado/mouse e controle no PC/PS4.
- HUD modular: vida, fome, armadura, stamina, hotbar e indicador de alvo.

## Próximas etapas
1. Validar esta cena no Godot 4.3+ e corrigir eventuais diferenças de versão.
2. Refazer o mundo com chunks/meshing para reduzir milhares de corpos individuais.
3. Adicionar inventário funcional, crafting, mineração, construção e salvamento.
4. Criar pipeline de texturas, modelos, skins e animações originais.
5. Multiplayer, perfis e loja somente com infraestrutura de rede/servidor.
6. Para PS4 homebrew, portar os sistemas para C++/OpenOrbis; a cena Godot não vira PKG automaticamente.

## Estado honesto
Este lobby é um primeiro incremento de código, ainda não executado/validado no Godot nesta sessão. Multijogador, Skin, Mundos, Loja e Configurações exibem avisos de desenvolvimento, não funcionalidades prontas. Nenhum APK, EBOOT ou PKG foi produzido.
