# Publicação do MINEPLUS no GitHub

Este diretório é a base versionável do projeto MINEPLUS.

## Criar o repositório pelo navegador do celular
1. Entre em https://github.com/new
2. Nome: `MINEPLUS-PS4`
3. Escolha Público ou Privado.
4. Não marque a opção de adicionar README (este projeto já contém um).
5. Crie o repositório.
6. Envie o conteúdo desta pasta para a raiz do repositório usando **Add file > Upload files**.

## Estado de compilação
Este pacote contém o projeto Godot e documentação de portabilidade. Ele NÃO contém um executável PS4, EBOOT.BIN ou PKG pronto. O empacotamento PS4 só pode ocorrer depois de integrar um runtime Godot compatível com PS4 e compilar no ambiente/toolchain correspondente.
