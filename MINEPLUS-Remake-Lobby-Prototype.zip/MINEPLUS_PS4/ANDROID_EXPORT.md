# Exportação Android (etapa posterior)

Para gerar APK/AAB, instale os templates de exportação da mesma versão do Godot e configure o Android SDK/JDK conforme a documentação oficial do Godot.
A exportação Android requer ferramentas de build Android; o projeto-fonte sozinho não é um instalador.
Comece validando a cena no editor Android. Não habilite permissões Android desnecessárias.
