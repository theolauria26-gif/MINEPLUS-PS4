# Shaders MINEPLUS

- `shaders/voxel_surface.gdshader`: material espacial para blocos, iluminação PBR simples e variação procedural discreta de cor.
- `shaders/water.gdshader`: água translúcida com ondulação animada por `TIME`.

O projeto usa o renderer `gl_compatibility` para ampliar a compatibilidade com GPUs móveis. Recursos avançados de tela (SSAO, SSR, volumetric fog) foram evitados nesta configuração para priorizar aparelhos Android variados.
