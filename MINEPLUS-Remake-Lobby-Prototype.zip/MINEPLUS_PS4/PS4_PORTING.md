# MINEPLUS — preparação de portabilidade para PS4

**Base:** MINEPLUS v0.6 (Godot 4.3 / GDScript)  
**Alvo informado:** PS4 com firmware 14.02 e GoldHEN.  
**Estado desta entrega:** preparação de código e controles; NÃO é um PKG.

## O que mudou nesta etapa (v0.7 PS4 Prep)

- Adicionado mapeamento inicial de botões de controle padrão:
  - Cross / A: pular
  - Square / X: atacar
  - Triangle / Y: alternar modo de construção
  - Circle / B: interação
- Analógico direito: câmera/visão.
- A leitura do controle é ativada quando um gamepad está conectado.
- A sensibilidade do analógico direito fica centralizada em `gamepad_look_sensitivity`.

Os índices de botões podem variar conforme o mapeamento que o driver/porta do sistema operacional apresenta. O mapeamento deve ser validado no hardware PS4 real e ajustado se necessário.

## Limite técnico importante

O projeto atual usa Godot 4 e GDScript. A OpenOrbis Toolchain fornece compiladores, bibliotecas e ferramentas para criar executáveis homebrew (`eboot.bin`) e pacotes `.pkg`, mas **não é um exportador de projetos Godot**. Para executar este jogo no PS4 é necessário obter/compilar uma porta do motor Godot compatível com PS4 ou portar o runtime/renderização e os sistemas do jogo para uma base nativa compatível.

Portanto, não renomeie o ZIP/APK para `.pkg`. Um pacote só é válido depois de conter um `eboot.bin` PS4 real, `param.sfo`, `icon0.png` e os dados do jogo, e de passar por teste no console.

## Próximas etapas técnicas

1. Definir a base de runtime: porta Godot para PS4 comprovadamente funcional ou reimplementação nativa.
2. Validar controle DualShock 4, áudio, arquivos, resolução e renderização no console.
3. Otimizar o mundo: substituir milhares de corpos/blocos individuais por chunks/meshes combinados.
4. Integrar o conteúdo e os shaders em uma build PS4.
5. Gerar `eboot.bin` com a toolchain e montar `.pkg` com LibOrbisPkg.
6. Testar instalação, inicialização, desempenho e salvamento no PS4 14.02.

## Desempenho

A versão atual cria blocos como nós físicos individuais. Isso é apenas protótipo e precisa ser substituído por chunk meshing/instancing antes de uma build de console. Não há alegação de FPS ou compatibilidade confirmada nesta etapa.
